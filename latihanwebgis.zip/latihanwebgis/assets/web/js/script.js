// Data RTH dari GeoJSON
const rthData = {
    "type": "FeatureCollection",
    "name": "titik_rth",
    "features": [
        { "type": "Feature", "properties": { "id": 1, "nama": "Modern South Valley", "link_gmaps": "https://maps.app.goo.gl/Dq2Uw1VgRxswqVt78", "jenis": "Lahan", "luas": "536.00 m²", "kondisi_eksisting": "Terawat", "vegetasi_dominan": "Pohon total 39, pohon sawit 3,pohon pisang" }},
        { "type": "Feature", "properties": { "id": 2, "nama": "Lapangan Ganevo", "link_gmaps": "https://maps.app.goo.gl/eawziXv7yLD4UHYm7", "jenis": "Lapangan", "luas": "1,088.29 m²", "kondisi_eksisting": "Terawat", "vegetasi_dominan": "4 Pohon pisang" }},
        { "type": "Feature", "properties": { "id": 3, "nama": "Lapangan Albatros Idola FC", "link_gmaps": "https://maps.app.goo.gl/4p1sKZhMHZFXTqJU9", "jenis": "Lapangan", "luas": "5,119.24 m²", "kondisi_eksisting": "Terawat", "vegetasi_dominan": "beringin 5, bambu 4,sawit 4" }},
        { "type": "Feature", "properties": { "id": 4, "nama": "Lapangan Pordas Blok Miring", "link_gmaps": "https://maps.app.goo.gl/53Q4teNiU4ffq5o69", "jenis": "Lapangan", "luas": "4.081,85 m²", "kondisi_eksisting": "Terawat", "vegetasi_dominan": "Pohon kelapa 1, Pohon Trembesi 2, " }},
        { "type": "Feature", "properties": { "id": 5, "nama": "Murai Residence", "link_gmaps": "https://maps.app.goo.gl/hd59LVapZ6vLEco5A", "jenis": "Lahan", "luas": "589,31 m²", "kondisi_eksisting": "Cukup Terawat", "vegetasi_dominan": "2 pohon" }},
        { "type": "Feature", "properties": { "id": 6, "nama": "Citra Garden Bintaro", "link_gmaps": "https://maps.app.goo.gl/xYuoyetd9zPjp4rKA", "jenis": "Lahan", "luas": "1,200.60 m²", "kondisi_eksisting": "Cukup Terawat", "vegetasi_dominan": "Pohon Ketapang Kencana 2, Pohon Palem 6, Pohon Pisang Hias 6, Pohon Tinggi Daun Lebat 7" }},
        { "type": "Feature", "properties": { "id": 7, "nama": "Taman Citra Garden Bintaro", "link_gmaps": "https://maps.app.goo.gl/twiohDNHWFCauwQk9", "jenis": "Taman", "luas": "2,142.47 m²", "kondisi_eksisting": "Terawat", "vegetasi_dominan": "Pohon Tabebuya 14 Pohon, Trembesi muda 5 pohon, " }},
        { "type": "Feature", "properties": { "id": 8, "nama": "Jalur Hijau Jalan Boulevard Bintari", "link_gmaps": "https://maps.app.goo.gl/wiEuk9pisaDEwdZb7", "jenis": "Jalur Hijau", "luas": "18,743.41 m²", "kondisi_eksisting": "Terawat", "vegetasi_dominan": "Pohon Tabebuya" }},
        { "type": "Feature", "properties": { "id": 9, "nama": "Lapangan Jl Seruni", "link_gmaps": "https://maps.app.goo.gl/mLPLoEAh9W3fPZv37", "jenis": "Lapangan", "luas": "878.08 m²", "kondisi_eksisting": "Terawat", "vegetasi_dominan": "Pohon Trembesi 1, Pohon Ketapang 2, Pohon Mangga 2" }},
        { "type": "Feature", "properties": { "id": 10, "nama": "Lapangan PSHT Rayon", "link_gmaps": "https://maps.app.goo.gl/vsAEzFcicrLehoXf7", "jenis": "Lapangan", "luas": "599,70 m²", "kondisi_eksisting": "Terawat", "vegetasi_dominan": "Pohon Ketapang Kencana 1, Pohon peneduh sedang 5, Pohon pisang 2" }},
        { "type": "Feature", "properties": { "id": 11, "nama": "Taman Pisang", "link_gmaps": "https://maps.app.goo.gl/hT7ENJMR4w2uXad59", "jenis": "Taman", "luas": "731.73 m²", "kondisi_eksisting": "Terawat", "vegetasi_dominan": "Pohon Trembesi 1, Pohon Pisang 5, Pohon Kelapa 1, Semak Pepaya 1, Bambu 1, Pohon Besar 2, Rumput Liar" }},
        { "type": "Feature", "properties": { "id": 12, "nama": "Lahan Asterloka Savana", "link_gmaps": "https://maps.app.goo.gl/J63F8iy1WUFikU569", "jenis": "Lahan", "luas": "333.43 m²", "kondisi_eksisting": "Cukup Terawat", "vegetasi_dominan": "Pohon ceri 1, Rumut Liar" }},
        { "type": "Feature", "properties": { "id": 13, "nama": "Lapangan di Jl Gelatik 1", "link_gmaps": "https://maps.app.goo.gl/CUDPADemMF4zoF1NA", "jenis": "Lapangan", "luas": "898.92 m²", "kondisi_eksisting": "Terawat", "vegetasi_dominan": "Pohon Pisang 10 pohon, Rumput Liar, Semak kecil" }},
        { "type": "Feature", "properties": { "id": 14, "nama": "Lapangan Hijau Tapak Saka", "link_gmaps": "https://maps.app.goo.gl/9hdsnW4GquBvUkbM9", "jenis": "Lapangan", "luas": "503.11 m²", "kondisi_eksisting": "Cukup Terawat", "vegetasi_dominan": "Semak Belukar, Pohon Kecil, Pohon Ceri 1, Rumput Liar" }},
        { "type": "Feature", "properties": { "id": 15, "nama": "Lapangan Roda", "link_gmaps": "https://maps.app.goo.gl/YWpGXafACNyu9vdH7", "jenis": "Lapangan", "luas": "768,39 m²", "kondisi_eksisting": "Terawat", "vegetasi_dominan": "Pohon Peneduh 3, Rumput Liar, Pohon Pisang 2, Tanaman Hias Pot Kecil" }},
        { "type": "Feature", "properties": { "id": 16, "nama": "Perumahan Ciputat Baru", "link_gmaps": "https://maps.app.goo.gl/M4GF9PSc5hzR5Pde7", "jenis": "Jalur Hijau", "luas": "887.75 m²", "kondisi_eksisting": "Terawat", "vegetasi_dominan": "Tanaman Hias Pot Kecil, Pohon Peneduh 3, Pohon Pisang 2" }},
        { "type": "Feature", "properties": { "id": 17, "nama": "Perumahan Grand Bintaro Asri", "link_gmaps": "https://maps.app.goo.gl/VsBjjiL3YvTmxH6i8", "jenis": "Jalur Hijau", "luas": "647.35 m²", "kondisi_eksisting": "Terawat", "vegetasi_dominan": "Pohon Tinggi Rimbun 2, Pohon Peneduh 4, Tanaman Hias Dekat Dinding/Depan Teras" }},
        { "type": "Feature", "properties": { "id": 18, "nama": "Perumahan Graha Permai", "link_gmaps": "https://maps.app.goo.gl/39c6TeEw9sJw2JuN7", "jenis": "Lahan", "luas": "852.63 m² ", "kondisi_eksisting": "Terawat", "vegetasi_dominan": "Pohon Besar 1, Pohon Palem Kecil 1, Pohon Cemara 8, Tanaman Pot di Pagar Depan" }},
        { "type": "Feature", "properties": { "id": 19, "nama": "Sanggar Kemuning", "link_gmaps": "https://maps.app.goo.gl/qw5crhTq32aVc1v76", "jenis": "Kebun", "luas": "2,121.97 m²", "kondisi_eksisting": "Terawat", "vegetasi_dominan": "Tanaman Hias Daun Lebar 8, Tanaman Pot 42, " }},
        { "type": "Feature", "properties": { "id": 20, "nama": "Pemakaman di Jl Ki Hajar Dewantara", "link_gmaps": "https://maps.app.goo.gl/122vwKT2zsvK99BB8", "jenis": "Pemakaman", "luas": "7.452,23 m²", "kondisi_eksisting": "Cukup Terawat", "vegetasi_dominan": null }},
        { "type": "Feature", "properties": { "id": 21, "nama": "Lahan di Jl Bangau", "link_gmaps": "https://maps.app.goo.gl/jev3fHR16RALBA2H6", "jenis": "Lahan", "luas": "26.723,56 m²", "kondisi_eksisting": "Cukup Terawat", "vegetasi_dominan": null }},
        { "type": "Feature", "properties": { "id": 22, "nama": "Villarelo Residence", "link_gmaps": "https://maps.app.goo.gl/PHQuNTBiGTZwnDaY8", "jenis": null, "luas": "286.64 m²", "kondisi_eksisting": "Terawat", "vegetasi_dominan": "Pohon Peneduh 2, Pohon Hias 1, Tanaman Semak 4" }},
        { "type": "Feature", "properties": { "id": 23, "nama": "TPBU Blok Miring", "link_gmaps": "https://maps.app.goo.gl/kRiu3SrnD8wNuhYz5", "jenis": "Pemakaman", "luas": "5.527,70 m²", "kondisi_eksisting": "Terawat", "vegetasi_dominan": null }},
        { "type": "Feature", "properties": { "id": 24, "nama": "Dreamland Mini Bike Park", "link_gmaps": "https://maps.app.goo.gl/fiJFxEejVjGMU8Du6", "jenis": "Taman", "luas": "3.465,73 m²", "kondisi_eksisting": "Terawat", "vegetasi_dominan": null }},
        { "type": "Feature", "properties": { "id": 25, "nama": "Kandank Jurank Creative Park", "link_gmaps": "https://maps.app.goo.gl/czEG8mYi45zN1d6b7", "jenis": "Taman", "luas": "1,374.09 m²", "kondisi_eksisting": "Terawat", "vegetasi_dominan": "Pohon Peneduh Tinggi 28, Tanaman Semak 8" }}
    ]
};

// Smooth Scrolling for Navigation Links
document.addEventListener('DOMContentLoaded', function() {
    // Smooth scroll for nav links
    const navLinks = document.querySelectorAll('.nav-link');
    
    navLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            const href = this.getAttribute('href');
            
            if (href.startsWith('#')) {
                e.preventDefault();
                const targetId = href.substring(1);
                const targetSection = document.getElementById(targetId);
                
                if (targetSection) {
                    // Remove active class from all links
                    navLinks.forEach(l => l.classList.remove('active'));
                    // Add active class to clicked link
                    this.classList.add('active');
                    
                    // Scroll to section
                    const navHeight = document.querySelector('.navbar').offsetHeight;
                    const targetPosition = targetSection.offsetTop - navHeight;
                    
                    window.scrollTo({
                        top: targetPosition,
                        behavior: 'smooth'
                    });
                }
            }
        });
    });

    // Active nav on scroll
    window.addEventListener('scroll', function() {
        const sections = document.querySelectorAll('section');
        const navHeight = document.querySelector('.navbar').offsetHeight;
        
        sections.forEach(section => {
            const sectionTop = section.offsetTop - navHeight - 100;
            const sectionBottom = sectionTop + section.offsetHeight;
            const scrollPosition = window.scrollY;
            
            if (scrollPosition >= sectionTop && scrollPosition < sectionBottom) {
                const id = section.getAttribute('id');
                navLinks.forEach(link => {
                    link.classList.remove('active');
                    if (link.getAttribute('href') === `#${id}`) {
                        link.classList.add('active');
                    }
                });
            }
        });
    });

    // Scroll to Top Button
    const scrollTopBtn = document.getElementById('scrollTop');
    
    window.addEventListener('scroll', function() {
        if (window.scrollY > 300) {
            scrollTopBtn.classList.add('show');
        } else {
            scrollTopBtn.classList.remove('show');
        }
    });
    
    scrollTopBtn.addEventListener('click', function() {
        window.scrollTo({
            top: 0,
            behavior: 'smooth'
        });
    });

    // Load RTH Data
    loadRTHData();
    calculateStatistics();

    // Contact Form Submit
    const contactForm = document.getElementById('contactForm');
    contactForm.addEventListener('submit', function(e) {
        e.preventDefault();
        alert('Terima kasih! Pesan Anda telah terkirim. Kami akan segera menghubungi Anda.');
        contactForm.reset();
    });
});

// Function to load RTH data into table
function loadRTHData() {
    const tableBody = document.getElementById('rthTableBody');
    let html = '';
    
    rthData.features.forEach((feature, index) => {
        const props = feature.properties;
        const kondisiBadge = props.kondisi_eksisting === 'Terawat' 
            ? 'bg-success' 
            : 'bg-warning text-dark';
        
        html += `
            <tr>
                <td>${index + 1}</td>
                <td><strong>${props.nama}</strong></td>
                <td><span class="badge bg-primary">${props.jenis || '-'}</span></td>
                <td>${props.luas}</td>
                <td><span class="badge ${kondisiBadge}">${props.kondisi_eksisting}</span></td>
                <td>${props.vegetasi_dominan || '-'}</td>
                <td>
                    <a href="${props.link_gmaps}" target="_blank" class="btn btn-sm btn-success">
                        <i class="fas fa-map-marker-alt"></i> Maps
                    </a>
                </td>
            </tr>
        `;
    });
    
    tableBody.innerHTML = html;
}

// Function to calculate statistics
function calculateStatistics() {
    const totalRTH = rthData.features.length;
    let terawat = 0;
    let cukupTerawat = 0;
    let totalLuas = 0;
    
    rthData.features.forEach(feature => {
        const props = feature.properties;
        
        // Count kondisi
        if (props.kondisi_eksisting === 'Terawat') {
            terawat++;
        } else if (props.kondisi_eksisting === 'Cukup Terawat') {
            cukupTerawat++;
        }
        
        // Calculate total luas (remove non-numeric characters and convert to number)
        if (props.luas) {
            const luasNum = parseFloat(props.luas.replace(/[^\d,.-]/g, '').replace(',', '.'));
            if (!isNaN(luasNum)) {
                totalLuas += luasNum;
            }
        }
    });
    
    // Update statistics in HTML
    document.getElementById('totalRTH').textContent = totalRTH;
    document.getElementById('terawat').textContent = terawat;
    document.getElementById('cukupTerawat').textContent = cukupTerawat;
    
    // Format total luas with thousand separator
    const formattedLuas = totalLuas.toLocaleString('id-ID', {
        minimumFractionDigits: 0,
        maximumFractionDigits: 2
    });
    document.getElementById('totalLuas').textContent = `${formattedLuas} m²`;
}

// Navbar background change on scroll
window.addEventListener('scroll', function() {
    const navbar = document.querySelector('.navbar');
    if (window.scrollY > 50) {
        navbar.style.backgroundColor = 'rgba(46, 204, 113, 0.95)';
        navbar.style.boxShadow = '0 2px 10px rgba(0,0,0,0.1)';
    } else {
        navbar.style.backgroundColor = 'rgba(46, 204, 113, 0.9)';
        navbar.style.boxShadow = 'none';
    }
});

// Animation on scroll
const animateOnScroll = function() {
    const elements = document.querySelectorAll('.feature-card, .stat-card, .profile-card, .contact-info-card');
    
    elements.forEach(element => {
        const elementTop = element.getBoundingClientRect().top;
        const elementBottom = element.getBoundingClientRect().bottom;
        
        if (elementTop < window.innerHeight && elementBottom > 0) {
            element.style.opacity = '1';
            element.style.transform = 'translateY(0)';
        }
    });
};

// Initial setup for animation
document.addEventListener('DOMContentLoaded', function() {
    const elements = document.querySelectorAll('.feature-card, .stat-card, .profile-card, .contact-info-card');
    
    elements.forEach(element => {
        element.style.opacity = '0';
        element.style.transform = 'translateY(30px)';
        element.style.transition = 'all 0.6s ease';
    });
    
    window.addEventListener('scroll', animateOnScroll);
    animateOnScroll(); // Run once on load
});