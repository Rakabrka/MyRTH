<?php
// Menggabungkan seluruh bagian layout
$this->load->view('layout/viewhead');
$this->load->view('layout/viewnav');               // navbar + buka content-wrapper
$this->load->view('layout/viewcontent');              // isi halaman (peta)
$this->load->view('layout/viewfooter');               // footer + tutup content-wrapper
