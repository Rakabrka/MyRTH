<?php
// Memuat view sesuai isi variabel $content dari controller Home
if (isset($content) && ! empty($content)) {
    $this->load->view($content);
}
