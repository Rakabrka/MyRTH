<body class="hold-transition layout-top-nav">
<div class="wrapper">

  <!-- Navbar -->
  <nav class="main-header navbar navbar-expand-md navbar-light navbar-dark">
    <div class="container">
      <a href="<?=base_url()?>" class="navbar-brand">
        <img src="<?=base_url()?>assets/template/dist/img/AdminLTELogo.png"
             alt="AdminLTE Logo"
             class="brand-image img-circle elevation-3"
             style="opacity: .8">
        <span style="color:gold" class="brand-text font-weight-light"><b>Geo-Info</b></span>
      </a>

      <button class="navbar-toggler order-1" type="button" data-toggle="collapse"
              data-target="#navbarCollapse" aria-controls="navbarCollapse"
              aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse order-3" id="navbarCollapse">
        <!-- Left navbar links -->
        <ul class="navbar-nav">
          <li class="nav-item">
            <a href="#" style="color:white" class="nav-link">Home</a>
          </li>
          <li class="nav-item">
            <a href="#" style="color:white" class="nav-link">Map</a>
          </li>
          <li class="nav-item dropdown">
            <a id="dropdownSubMenu1" href="#" data-toggle="dropdown" aria-haspopup="true"
               aria-expanded="false" style="color:white" class="nav-link dropdown-toggle">
              Download
            </a>
            <ul aria-labelledby="dropdownSubMenu1" class="dropdown-menu border-0 shadow">
              <li><a href="<?=base_url('assets/images.zip')?>"  class="dropdown-item">images.zip</a></li>
              <li><a href="<?=base_url('assets/images2.zip')?>" class="dropdown-item">images2.zip</a></li>
              <li><a href="<?=base_url('assets/images3.zip')?>" class="dropdown-item">images3.zip</a></li>
            </ul>
          </li>
        </ul>
      </div><!-- /.navbar-collapse -->

    </div><!-- /.container -->
  </nav>
  <!-- /.navbar -->

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
