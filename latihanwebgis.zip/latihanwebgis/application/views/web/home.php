<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SIG Ruang Terbuka Hijau - Sawah Lama, Ciputat</title>
    
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.2/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="<?=base_url()?>assets/web/css/style.css">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-success fixed-top shadow">
        <div class="container-fluid">
            <a class="navbar-brand" href="#home">
                <i class="fas fa-map-marked-alt"></i> MyRTH
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link active" href="#home">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#about">About</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#map">Map</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#data">Data RTH</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#profile">Profile</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#contact">Contact</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <section id="home" class="hero-section">
        <div class="hero-overlay"></div>
        <div class="container hero-content">
            <div class="row align-items-center">
                <div class="col-lg-8 mx-auto text-center">
                    <h1 class="display-3 fw-bold text-white mb-4 animate-fade-in">
                        SIG Ruang Terbuka Hijau<br>
                        <span style="font-size: 0.7em;">Kelurahan Sawah Lama</span>
                    </h1>
                    <p class="lead text-white mb-4">
                        Platform pemetaan digital dan monitoring persebaran Ruang Terbuka Hijau (RTH) 
                        di wilayah <strong>Kelurahan Sawah Lama, Kecamatan Ciputat</strong> untuk mendukung tata kota yang berkelanjutan.
                    </p>
                    <div class="d-flex gap-3 justify-content-center">
                        <a href="#map" class="btn btn-light btn-lg">
                            <i class="fas fa-map"></i> Lihat Peta
                        </a>
                        <a href="#data" class="btn btn-outline-light btn-lg">
                            <i class="fas fa-database"></i> Data RTH
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section id="about" class="section-padding min-vh-100 d-flex align-items-center">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 mx-auto text-center mb-5">
                    <h2 class="section-title">Tentang MyRTH Sawah Lama</h2>
                    <div class="title-divider"></div>
                </div>
            </div>
            <div class="row g-4">
                <div class="col-md-4">
                    <div class="feature-card text-center">
                        <div class="feature-icon">
                            <i class="fas fa-tree"></i>
                        </div>
                        <h4>Ruang Terbuka Hijau</h4>
                        <p>Fokus pada identifikasi area hijau publik dan privat di kawasan Sawah Lama sebagai paru-paru kota Ciputat.</p>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="feature-card text-center">
                        <div class="feature-icon">
                            <i class="fas fa-map-marked-alt"></i>
                        </div>
                        <h4>Pemetaan Digital</h4>
                        <p>Visualisasi spasial interaktif untuk memudahkan warga dan pemerintah memantau distribusi RTH.</p>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="feature-card text-center">
                        <div class="feature-icon">
                            <i class="fas fa-chart-line"></i>
                        </div>
                        <h4>Monitoring Data</h4>
                        <p>Pemantauan kondisi eksisting vegetasi dan luasan area hijau secara real-time dan terukur.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section id="map" class="bg-light pb-0 pt-5">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center mb-2">
                    <h2 class="section-title">Peta Persebaran RTH</h2>
                    <div class="title-divider"></div>
                    <p class="text-muted">Wilayah Kelurahan Sawah Lama, Ciputat</p>
                </div>
            </div>
        </div>

        <div class="container-fluid p-0">
            <div class="map-container shadow-sm">
                <iframe src="<?=base_url()?>/home" width="100%" height="690" frameborder="0" style="border:0; display: block;" allowfullscreen></iframe>
            </div>
        </div>
    </section>

    <section id="data" class="section-padding">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="text-center mb-5">
                        <h2 class="section-title">Data Tabular RTH</h2>
                        <div class="title-divider"></div>
                        <p class="text-muted">Rekapitulasi Data RTH Sawah Lama</p>
                    </div>
                    
                    <div class="row g-4 mb-5">
                        <div class="col-md-3">
                            <div class="stat-card">
                                <div class="stat-icon bg-success">
                                    <i class="fas fa-map-marker-alt"></i>
                                </div>
                                <div class="stat-content">
                                    <h3 id="totalRTH">25</h3>
                                    <p>Total Lokasi</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="stat-card">
                                <div class="stat-icon bg-primary">
                                    <i class="fas fa-expand"></i>
                                </div>
                                <div class="stat-content">
                                    <h3 id="totalLuas">85,123 m²</h3>
                                    <p>Total Luas Area</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-2">
                            <div class="stat-card">
                                <div class="stat-icon bg-warning">
                                    <i class="fas fa-leaf"></i>
                                </div>
                                <div class="stat-content">
                                    <h3 id="terawat">20</h3>
                                    <p>Terawat</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="stat-card">
                                <div class="stat-icon bg-info">
                                    <i class="fas fa-seedling"></i>
                                </div>
                                <div class="stat-content">
                                    <h3 id="cukupTerawat">5</h3>
                                    <p>Cukup Terawat</p>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="table-responsive shadow">
                        <table class="table table-hover" id="rthTable">
                            <thead class="table-success">
                                <tr>
                                    <th>No</th>
                                    <th>Nama Lokasi</th>
                                    <th>Jenis</th>
                                    <th>Luas</th>
                                    <th>Kondisi</th>
                                    <th>Vegetasi Dominan</th>
                                    <th>Maps</th>
                                </tr>
                            </thead>
                            <tbody id="rthTableBody">
                                </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </section>

<section id="profile" class="section-padding bg-light min-vh-100 d-flex align-items-center">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 mx-auto text-center mb-2">
                    <h2 class="section-title">Profil Tim</h2>
                    <div class="title-divider"></div>
                    <p class="text-muted">Tim Pengembang SIG MyRTH</p>
                </div>
            </div>
            
            <div class="row g-3 justify-content-center">
                
                <div class="col-md-3 col-lg-4">
                    <div class="profile-card p-3 h-100 shadow-sm"> <div class="profile-img mb-3" style="width: 80px; height: 80px; font-size: 2rem;"> 
                            <i class="fas fa-user-circle"></i>
                        </div>
                        <h5 class="mb-1">Raka</h5>
                        <p class="text-muted small mb-2">Nigga Manager</p>
                        <div class="profile-social">
                            <a href="#"><i class="fab fa-linkedin"></i></a>
                            <a href="#"><i class="fab fa-github"></i></a>
                            <a href="#"><i class="fas fa-envelope"></i></a>
                        </div>
                    </div>
                </div>

                <div class="col-md-6 col-lg-4">
                    <div class="profile-card p-3 h-100 shadow-sm">
                        <div class="profile-img mb-3" style="width: 80px; height: 80px; font-size: 2rem;">
                            <i class="fas fa-user-circle"></i>
                        </div>
                        <h5 class="mb-1">Madan</h5>
                        <p class="text-muted small mb-2">Nigga Specialist</p>
                        <div class="profile-social">
                            <a href="#"><i class="fab fa-linkedin"></i></a>
                            <a href="#"><i class="fab fa-github"></i></a>
                            <a href="#"><i class="fas fa-envelope"></i></a>
                        </div>
                    </div>
                </div>

                <div class="col-md-6 col-lg-4">
                    <div class="profile-card p-3 h-100 shadow-sm">
                        <div class="profile-img mb-3" style="width: 80px; height: 80px; font-size: 2rem;">
                            <i class="fas fa-user-circle"></i>
                        </div>
                        <h5 class="mb-1">Dimas</h5>
                        <p class="text-muted small mb-2">Nigga Developer</p>
                        <div class="profile-social">
                            <a href="#"><i class="fab fa-linkedin"></i></a>
                            <a href="#"><i class="fab fa-github"></i></a>
                            <a href="#"><i class="fas fa-envelope"></i></a>
                        </div>
                    </div>
                </div>

                <div class="col-md-6 col-lg-4">
                    <div class="profile-card p-3 h-100 shadow-sm">
                        <div class="profile-img mb-3" style="width: 80px; height: 80px; font-size: 2rem;">
                            <i class="fas fa-user-circle"></i>
                        </div>
                        <h5 class="mb-1">Dapa</h5>
                        <p class="text-muted small mb-2">Nigga Analyst</p>
                        <div class="profile-social">
                            <a href="#"><i class="fab fa-linkedin"></i></a>
                            <a href="#"><i class="fab fa-github"></i></a>
                            <a href="#"><i class="fas fa-envelope"></i></a>
                        </div>
                    </div>
                </div>

                <div class="col-md-6 col-lg-4">
                    <div class="profile-card p-3 h-100 shadow-sm">
                        <div class="profile-img mb-3" style="width: 80px; height: 80px; font-size: 2rem;">
                            <i class="fas fa-user-circle"></i>
                        </div>
                        <h5 class="mb-1">Sufyanti</h5>
                        <p class="text-muted small mb-2">Nigga Designer</p>
                        <div class="profile-social">
                            <a href="#"><i class="fab fa-linkedin"></i></a>
                            <a href="#"><i class="fab fa-github"></i></a>
                            <a href="#"><i class="fas fa-envelope"></i></a>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </section>

    <section id="contact" class="section-padding">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 mx-auto text-center mb-5">
                    <h2 class="section-title">Hubungi Kami</h2>
                    <div class="title-divider"></div>
                    <p class="text-muted">Sampaikan pertanyaan atau saran Anda</p>
                </div>
            </div>
            <div class="row g-4">
                <div class="col-lg-4">
                    <div class="contact-info-card">
                        <div class="contact-icon">
                            <i class="fas fa-map-marker-alt"></i>
                        </div>
                        <h5>Alamat</h5>
                        <p>Tangerang Selatan, Banten<br>Indonesia</p>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="contact-info-card">
                        <div class="contact-icon">
                            <i class="fas fa-phone"></i>
                        </div>
                        <h5>Telepon</h5>
                        <p>+62 6969696969</p>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="contact-info-card">
                        <div class="contact-icon">
                            <i class="fas fa-envelope"></i>
                        </div>
                        <h5>Email</h5>
                        <p>myruangterbukahijau69.com</p>
                    </div>
                </div>
            </div>
            <div class="row mt-5">
                <div class="col-lg-8 mx-auto">
                    <form class="contact-form shadow" id="contactForm">
                        <div class="row g-3">
                            <div class="col-md-6">
                                <input type="text" class="form-control" placeholder="Nama Lengkap" required>
                            </div>
                            <div class="col-md-6">
                                <input type="email" class="form-control" placeholder="Email" required>
                            </div>
                            <div class="col-12">
                                <input type="text" class="form-control" placeholder="Subjek" required>
                            </div>
                            <div class="col-12">
                                <textarea class="form-control" rows="5" placeholder="Pesan Anda" required></textarea>
                            </div>
                            <div class="col-12 text-center">
                                <button type="submit" class="btn btn-success btn-lg">
                                    <i class="fas fa-paper-plane"></i> Kirim Pesan
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </section>

    <footer class="footer">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <p class="mb-0">&copy; 2024 SIG Ruang Terbuka Hijau. All Rights Reserved.</p>
                    <p class="mb-0 mt-2">
                        <a href="#home" class="text-white me-3"><i class="fas fa-home"></i></a>
                        <a href="#" class="text-white me-3"><i class="fab fa-facebook"></i></a>
                        <a href="#" class="text-white me-3"><i class="fab fa-twitter"></i></a>
                        <a href="#" class="text-white"><i class="fab fa-instagram"></i></a>
                    </p>
                </div>
            </div>
        </div>
    </footer>

    <button id="scrollTop" class="scroll-top">
        <i class="fas fa-arrow-up"></i>
    </button>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.2/js/bootstrap.bundle.min.js"></script>
    <script src="<?=base_url()?>assets/web/js/script.js"></script>
</body>
</html>