<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Web GIS - Ruang Terbuka Hijau</title>
    <link rel="stylesheet" href="<?=base_url()?>assets/web/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
    <!-- Header -->
    <header class="header">
        <div class="container">
            <div class="logo">
                <i class="fas fa-tree"></i>
                <span>RTH GIS</span>
            </div>
            <nav class="navbar">
                <ul>
                    <li><a href="#home" class="active">Beranda</a></li>
                    <li><a href="#about">Tentang</a></li>
                    <li><a href="#map">Peta</a></li>
                    <li><a href="#data">Data RTH</a></li>
                    <li><a href="#contact">Kontak</a></li>
                </ul>
            </nav>
            <div class="menu-toggle">
                <i class="fas fa-bars"></i>
            </div>
        </div>
    </header>

    <!-- Hero Section -->
    <section id="home" class="hero">
        <div class="hero-overlay"></div>
        <div class="hero-content">
            <h1>Sistem Informasi Geografis</h1>
            <h2>Ruang Terbuka Hijau</h2>
            <p>Memetakan dan mengelola ruang terbuka hijau untuk kota yang lebih hijau dan sehat</p>
            <div class="hero-buttons">
                <a href="#map" class="btn btn-primary">Lihat Peta</a>
                <a href="#about" class="btn btn-secondary">Pelajari Lebih Lanjut</a>
            </div>
        </div>
        <div class="scroll-down">
            <i class="fas fa-chevron-down"></i>
        </div>
    </section>

    <!-- About Section -->
    <section id="about" class="about">
        <div class="container">
            <div class="section-header">
                <h2>Tentang RTH</h2>
                <p>Ruang Terbuka Hijau untuk Kehidupan yang Lebih Baik</p>
            </div>
            <div class="about-content">
                <div class="about-item">
                    <div class="icon-box">
                        <i class="fas fa-leaf"></i>
                    </div>
                    <h3>Manfaat Lingkungan</h3>
                    <p>RTH membantu menyerap polusi udara, mengurangi suhu kota, dan meningkatkan kualitas udara</p>
                </div>
                <div class="about-item">
                    <div class="icon-box">
                        <i class="fas fa-heart"></i>
                    </div>
                    <h3>Kesehatan Masyarakat</h3>
                    <p>Ruang terbuka hijau memberikan tempat rekreasi dan olahraga untuk meningkatkan kesehatan</p>
                </div>
                <div class="about-item">
                    <div class="icon-box">
                        <i class="fas fa-city"></i>
                    </div>
                    <h3>Kota Berkelanjutan</h3>
                    <p>RTH adalah bagian penting dari perencanaan kota yang berkelanjutan dan ramah lingkungan</p>
                </div>
            </div>
        </div>
    </section>

    <!-- Map Section -->
    <section id="map" class="map-section">
        <div class="container-full">
            <div class="section-header">
                <h2>Peta Sebaran RTH</h2>
                <p>Jelajahi lokasi ruang terbuka hijau di wilayah Anda</p>
            </div>
            <div class="map-container">
                <!-- memanggil web -->
                <iframe src="<?=base_url()?>home" width="100%" height="650"></iframe>
            </div>
        </div>
    </section>

    <!-- Statistics Section -->
    <section id="data" class="statistics">
        <div class="container">
            <div class="section-header">
                <h2>Data & Statistik</h2>
                <p>Informasi Ruang Terbuka Hijau</p>
            </div>
            <div class="stats-grid">
                <div class="stat-card">
                    <i class="fas fa-map-marked-alt"></i>
                    <h3 class="stat-number" data-target="125">0</h3>
                    <p>Lokasi RTH</p>
                </div>
                <div class="stat-card">
                    <i class="fas fa-chart-area"></i>
                    <h3 class="stat-number" data-target="450">0</h3>
                    <p>Hektar Total</p>
                </div>
                <div class="stat-card">
                    <i class="fas fa-tree"></i>
                    <h3 class="stat-number" data-target="15000">0</h3>
                    <p>Pohon Tertanam</p>
                </div>
                <div class="stat-card">
                    <i class="fas fa-users"></i>
                    <h3 class="stat-number" data-target="50000">0</h3>
                    <p>Pengunjung/Bulan</p>
                </div>
            </div>
        </div>
    </section>

    <!-- Contact Section -->
    <section id="contact" class="contact">
        <div class="container">
            <div class="section-header">
                <h2>Hubungi Kami</h2>
                <p>Punya pertanyaan atau saran? Silakan hubungi kami</p>
            </div>
            <div class="contact-content">
                <div class="contact-info">
                    <div class="info-item">
                        <i class="fas fa-map-marker-alt"></i>
                        <div>
                            <h4>Alamat</h4>
                            <p>Jl. Lingkungan Hijau No. 123, Kota Hijau</p>
                        </div>
                    </div>
                    <div class="info-item">
                        <i class="fas fa-phone"></i>
                        <div>
                            <h4>Telepon</h4>
                            <p>+62 123 4567 8900</p>
                        </div>
                    </div>
                    <div class="info-item">
                        <i class="fas fa-envelope"></i>
                        <div>
                            <h4>Email</h4>
                            <p>info@rthgis.id</p>
                        </div>
                    </div>
                </div>
                <div class="contact-form">
                    <form>
                        <input type="text" placeholder="Nama Anda" required>
                        <input type="email" placeholder="Email Anda" required>
                        <textarea placeholder="Pesan Anda" rows="5" required></textarea>
                        <button type="submit" class="btn btn-primary">Kirim Pesan</button>
                    </form>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer class="footer">
        <div class="container">
            <div class="footer-content">
                <div class="footer-section">
                    <h3><i class="fas fa-tree"></i> RTH GIS</h3>
                    <p>Sistem Informasi Geografis untuk pengelolaan dan pemantauan ruang terbuka hijau yang berkelanjutan.</p>
                    <div class="social-links">
                        <a href="#"><i class="fab fa-facebook"></i></a>
                        <a href="#"><i class="fab fa-twitter"></i></a>
                        <a href="#"><i class="fab fa-instagram"></i></a>
                        <a href="#"><i class="fab fa-linkedin"></i></a>
                    </div>
                </div>
                <div class="footer-section">
                    <h4>Link Cepat</h4>
                    <ul>
                        <li><a href="#home">Beranda</a></li>
                        <li><a href="#about">Tentang</a></li>
                        <li><a href="#map">Peta</a></li>
                        <li><a href="#contact">Kontak</a></li>
                    </ul>
                </div>
                <div class="footer-section">
                    <h4>Informasi</h4>
                    <ul>
                        <li><a href="#">Kebijakan Privasi</a></li>
                        <li><a href="#">Syarat & Ketentuan</a></li>
                        <li><a href="#">FAQ</a></li>
                        <li><a href="#">Bantuan</a></li>
                    </ul>
                </div>
            </div>
            <div class="footer-bottom">
                <p>&copy; 2024 RTH GIS. All rights reserved.</p>
            </div>
        </div>
    </footer>

    <script src="<?=base_url()?>assets/web/js/script.js"></script>
</body>
</html>